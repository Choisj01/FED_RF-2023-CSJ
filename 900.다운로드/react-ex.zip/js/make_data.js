let aa = ["dfdfd","aaaaa","bbbbb","ddddd"]
let bb = '';
let cc = (x)=> Math.floor(Math.random()*x)
for(let x=0;x<100;x++){
bb += `
    {
        idx:'${x}',
        gno:'${aa[cc(4)]}',
    },
`;
}

// console.log(bb)

let mm=[
    {
        idx:'0',
        gno:'dfdfd',
    },

    {
        idx:'1',
        gno:'ddddd',
    },

    {
        idx:'2',
        gno:'dfdfd',
    },

    {
        idx:'3',
        gno:'bbbbb',
    },

    {
        idx:'4',
        gno:'ddddd',
    },

    {
        idx:'5',
        gno:'bbbbb',
    },

    {
        idx:'6',
        gno:'aaaaa',
    },

    {
        idx:'7',
        gno:'ddddd',
    },

    {
        idx:'8',
        gno:'aaaaa',
    },

    {
        idx:'9',
        gno:'aaaaa',
    },

    {
        idx:'10',
        gno:'bbbbb',
    },

    {
        idx:'11',
        gno:'dfdfd',
    },

    {
        idx:'12',
        gno:'bbbbb',
    },

    {
        idx:'13',
        gno:'ddddd',
    },

    {
        idx:'14',
        gno:'aaaaa',
    },

    {
        idx:'15',
        gno:'dfdfd',
    },

    {
        idx:'16',
        gno:'aaaaa',
    },

    {
        idx:'17',
        gno:'ddddd',
    },

    {
        idx:'18',
        gno:'ddddd',
    },

    {
        idx:'19',
        gno:'ddddd',
    },

    {
        idx:'20',
        gno:'dfdfd',
    },

    {
        idx:'21',
        gno:'bbbbb',
    },

    {
        idx:'22',
        gno:'dfdfd',
    },

    {
        idx:'23',
        gno:'bbbbb',
    },

    {
        idx:'24',
        gno:'bbbbb',
    },

    {
        idx:'25',
        gno:'bbbbb',
    },

    {
        idx:'26',
        gno:'bbbbb',
    },

    {
        idx:'27',
        gno:'bbbbb',
    },

    {
        idx:'28',
        gno:'bbbbb',
    },

    {
        idx:'29',
        gno:'aaaaa',
    },

    {
        idx:'30',
        gno:'dfdfd',
    },

    {
        idx:'31',
        gno:'ddddd',
    },

    {
        idx:'32',
        gno:'aaaaa',
    },

    {
        idx:'33',
        gno:'bbbbb',
    },

    {
        idx:'34',
        gno:'ddddd',
    },

    {
        idx:'35',
        gno:'ddddd',
    },

    {
        idx:'36',
        gno:'aaaaa',
    },

    {
        idx:'37',
        gno:'ddddd',
    },

    {
        idx:'38',
        gno:'dfdfd',
    },

    {
        idx:'39',
        gno:'dfdfd',
    },

    {
        idx:'40',
        gno:'bbbbb',
    },

    {
        idx:'41',
        gno:'ddddd',
    },

    {
        idx:'42',
        gno:'aaaaa',
    },

    {
        idx:'43',
        gno:'aaaaa',
    },

    {
        idx:'44',
        gno:'aaaaa',
    },

    {
        idx:'45',
        gno:'ddddd',
    },

    {
        idx:'46',
        gno:'ddddd',
    },

    {
        idx:'47',
        gno:'ddddd',
    },

    {
        idx:'48',
        gno:'ddddd',
    },

    {
        idx:'49',
        gno:'dfdfd',
    },

    {
        idx:'50',
        gno:'aaaaa',
    },

    {
        idx:'51',
        gno:'ddddd',
    },

    {
        idx:'52',
        gno:'ddddd',
    },

    {
        idx:'53',
        gno:'bbbbb',
    },

    {
        idx:'54',
        gno:'dfdfd',
    },

    {
        idx:'55',
        gno:'bbbbb',
    },

    {
        idx:'56',
        gno:'bbbbb',
    },

    {
        idx:'57',
        gno:'ddddd',
    },

    {
        idx:'58',
        gno:'bbbbb',
    },

    {
        idx:'59',
        gno:'dfdfd',
    },

    {
        idx:'60',
        gno:'bbbbb',
    },

    {
        idx:'61',
        gno:'dfdfd',
    },

    {
        idx:'62',
        gno:'ddddd',
    },

    {
        idx:'63',
        gno:'bbbbb',
    },

    {
        idx:'64',
        gno:'ddddd',
    },

    {
        idx:'65',
        gno:'aaaaa',
    },

    {
        idx:'66',
        gno:'bbbbb',
    },

    {
        idx:'67',
        gno:'aaaaa',
    },

    {
        idx:'68',
        gno:'aaaaa',
    },

    {
        idx:'69',
        gno:'aaaaa',
    },

    {
        idx:'70',
        gno:'dfdfd',
    },

    {
        idx:'71',
        gno:'dfdfd',
    },

    {
        idx:'72',
        gno:'ddddd',
    },

    {
        idx:'73',
        gno:'dfdfd',
    },

    {
        idx:'74',
        gno:'bbbbb',
    },

    {
        idx:'75',
        gno:'bbbbb',
    },

    {
        idx:'76',
        gno:'ddddd',
    },

    {
        idx:'77',
        gno:'bbbbb',
    },

    {
        idx:'78',
        gno:'ddddd',
    },

    {
        idx:'79',
        gno:'bbbbb',
    },

    {
        idx:'80',
        gno:'ddddd',
    },

    {
        idx:'81',
        gno:'aaaaa',
    },

    {
        idx:'82',
        gno:'ddddd',
    },

    {
        idx:'83',
        gno:'ddddd',
    },

    {
        idx:'84',
        gno:'dfdfd',
    },

    {
        idx:'85',
        gno:'dfdfd',
    },

    {
        idx:'86',
        gno:'aaaaa',
    },

    {
        idx:'87',
        gno:'bbbbb',
    },

    {
        idx:'88',
        gno:'ddddd',
    },

    {
        idx:'89',
        gno:'ddddd',
    },

    {
        idx:'90',
        gno:'bbbbb',
    },

    {
        idx:'91',
        gno:'aaaaa',
    },

    {
        idx:'92',
        gno:'dfdfd',
    },

    {
        idx:'93',
        gno:'ddddd',
    },

    {
        idx:'94',
        gno:'aaaaa',
    },

    {
        idx:'95',
        gno:'bbbbb',
    },

    {
        idx:'96',
        gno:'aaaaa',
    },

    {
        idx:'97',
        gno:'aaaaa',
    },

    {
        idx:'98',
        gno:'dfdfd',
    },

    {
        idx:'99',
        gno:'bbbbb',
    },

]

console.log(mm)